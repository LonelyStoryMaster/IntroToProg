my_bytes = b'This is a bytes literal'

print(my_bytes)
print(type(my_bytes))