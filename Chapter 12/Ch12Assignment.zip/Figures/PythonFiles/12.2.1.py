f = open('F:\\CIS1415\\IntroToProgramming\\Chapter 12\\Figures\\TextFiles\\12.2.1.txt', 'w')
f.write("Example string:\n  test...")
f.close()